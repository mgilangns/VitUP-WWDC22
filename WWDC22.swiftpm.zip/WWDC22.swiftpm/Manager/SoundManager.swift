//
//  File.swift
//  WWDC22
//
//  Created by Muhammad Gilang Nursyahroni on 24/04/22.
//

import Foundation
import AVKit

class SoundManager: ObservableObject {
    
    static let instance = SoundManager()
    
    var player: AVAudioPlayer?
    
    func playSound(){
        
        guard let url = Bundle.main.url(forResource: "mixkit-select-click-1109", withExtension: ".wav") else {return}
        
        do{
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
            
        }catch let error {
            
            print("error playing sound. \(error.localizedDescription)")
        }
    }
}

