//
//  PomodoroManager.swift
//  WWDC22
//
//  Created by Muhammad Gilang Nursyahroni on 18/04/22.
//

import Foundation

enum PomodoroState{
    case notStarted
    case work
    case rest
}

enum PomodoroPlan: String{
    case beginner = "12:12"
    case intermediate = "16:8"
    case advanced = "20:4"
    
    var pomodoroPeriod: Double{
        switch self {
        case .beginner:
            return 12
        case .intermediate:
            return 15
        case .advanced:
            return 20
        }
    }
}

class PomodoroManager: ObservableObject {
    @Published private(set) var pomodoroState: PomodoroState = .notStarted
    @Published private(set) var pomodoroPlan: PomodoroPlan = .intermediate
    @Published private(set) var startTime: Date {
        didSet{
            print("startTime", startTime.formatted(.dateTime.minute().second()))
            if isPaused == false {
                if pomodoroState == .work {
                    endTime = startTime.addingTimeInterval(workTime)
                } else{
                    endTime = startTime.addingTimeInterval(restTime)
                }
            }
        }
    }
    
    @Published private(set) var endTime: Date {
        didSet {
            print("endTime", endTime.formatted(.dateTime.minute().second()))
        }
    }
    
    @Published private(set) var elapsed: Bool = false
    @Published private(set) var elapsedTime: Double = 0.0
    @Published private(set) var isPaused: Bool = false
    @Published private(set) var progress: Double = 0.0
    
    var workTime: Double {
        return 1500
    }
    var restTime: Double {
        return 300
    }
    
    
    init() {
        
        let calendar = Calendar.current
        
        let components = DateComponents(hour: 20)
        
        let scheduleTime = calendar.nextDate(after: .now, matching: components, matchingPolicy: .nextTime)!
        print("scheduleTime", scheduleTime.formatted(.dateTime.minute().second()))
        
        startTime = scheduleTime
        
        
        endTime = scheduleTime.addingTimeInterval(PomodoroPlan.intermediate.pomodoroPeriod)
    }
    
    func toggleStart(){
        pomodoroState = pomodoroState == .notStarted ? .work : .notStarted
        startTime = Date()
        elapsedTime = 0.0
        progress = 0
    }
    
    func togglePomodoroState(){
        pomodoroState = pomodoroState == .work ? .rest : .work
        startTime = Date()
        elapsedTime = 0.0
    }
    
    func togglePaused(){
        isPaused = isPaused == false ? true : false
    }
    
    func track() {
        guard pomodoroState != .notStarted else { return }
        print("now", Date().formatted(.dateTime.minute().second()))
        
        if endTime >= Date(){
            print("Not Elapsed")
            elapsed = false
        }
        else{
            print("Elapsed")
            elapsed = true
        }
        
        if isPaused == false {
            elapsedTime += 1
            print("elapsedTime", elapsedTime)
        }
        
        let totalTime = pomodoroState == .work ? workTime : restTime
        progress = (elapsedTime / totalTime * 100) / 100
        print("progress", progress)
    }
    
    func stopTimer(){
        
    }
}

