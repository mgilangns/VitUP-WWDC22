//
//  ProgressRing.swift
//  WWDC22
//
//  Created by Muhammad Gilang Nursyahroni on 18/04/22.
//

import SwiftUI

struct ProgressRing: View {
    @EnvironmentObject var pomodoroManager: PomodoroManager
    
    @State var timeToShow = 0
    @State var workTimeRemaining = 5
    @State var breakTimeRemaining = 3
    @State var timeToWork = true
    
    let workPeriodLength = 5
    
    let breakPeriodLength = 3
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    func convertSecondsToTime(timeInSeconds : Int) -> String{
        let minutes = timeInSeconds / 60
        
        let seconds = timeInSeconds % 60
        
        return String(format: "%02i:%02i", minutes, seconds)
    }
    
    var body: some View {
        ZStack{
            //MARK: Placeholder Ring
            
            Circle()
                .stroke(lineWidth: 20)
                .foregroundColor(.gray)
                .opacity(0.1)
            
            //MARK: Colored Ring
            
            Circle()
                .trim(from: 0.0, to: min(pomodoroManager.progress, 1.0))
                .stroke(Color("Accent"), style: (StrokeStyle(lineWidth: 15.0, lineCap: .round, lineJoin: .round)))
                .rotationEffect((Angle(degrees: 270)))
                .animation(.easeInOut(duration: 1.0), value: pomodoroManager.progress)
            
            VStack(spacing: 30){
                if pomodoroManager.pomodoroState == .notStarted {
                    //MARK: Idle State
                    
                    GifImage("Hi")
                        .frame(width: 290, height: 290, alignment: .center)
                        .clipShape(Circle())
                        .allowsHitTesting(false)
                }
                else if pomodoroManager.pomodoroState == .work{
                    //MARK: Work State
                    
                    GifImage("Work")
                        .frame(width: 290, height: 290, alignment: .center)
                        .clipShape(Circle())
                        .allowsHitTesting(false)
                }
                else{
                    //MARK: Exercise State
                    
                    GifImage("Exercise")
                        .frame(width: 290, height: 290, alignment: .center)
                        .clipShape(Circle())
                        .allowsHitTesting(false)
                }
                
            }
        }
        .frame(width: 300, height: 300)
        .padding()
        .onReceive(timer) { _ in
            pomodoroManager.track()
        }
        .onReceive(timer){ _ in
            if pomodoroManager.progress >= 1{
                
                pomodoroManager.togglePomodoroState()
                SoundManager.instance.playSound()
            }
        }
    }
}

struct ProgressRing_Previews: PreviewProvider {
    static var previews: some View {
        ProgressRing()
            .environmentObject(PomodoroManager())
    }
}
