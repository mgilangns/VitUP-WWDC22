//
//  File.swift
//  VitUP
//
//  Created by Muhammad Gilang Nursyahroni on 24/04/22.
//

import Foundation
import SwiftUI

struct SplashView: View {
    
    
    @State var isActive:Bool = false
    
    var body: some View {
        VStack {
            
            if self.isActive {
                
                MainView()
            } else {
                
                Image("launchScreen")
                    .resizable()
                    .scaledToFit()
            }
        }
        
        .onAppear {
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                
                withAnimation {
                    self.isActive = true
                }
            }
        }
    }
}
