import SwiftUI

struct OnboardingView: View {
    
    @State private var indexPage = 0
    @Binding var shouldShowOnboarding: Bool
    @State var isHidden = false
    
    var body: some View {
        ZStack{
            
            NavigationView{
                
                TabView(selection: $indexPage){
                    ForEach(0..<onboardingScreens.count){ it in
                        ZStack {
                            
                            VStack(spacing: 20){
                                // MARK: -HEADER
                                
                                ZStack{
                                    //
                                    Circle()
                                        .stroke(lineWidth: 20)
                                        .foregroundColor(.gray)
                                        .frame(width: 300, height: 300, alignment: .center)
                                        .opacity(0.1)
                                    
                                    GifImage(onboardingScreens[it].bgImage)
                                        .clipShape(Circle())
                                    //.resizable()
                                    
                                        .frame(width: 300, height: 300, alignment: .center)
                                        .scaledToFit()
                                        .allowsHitTesting(false)
                                }//: HEADER
                                .padding()
                                // MARK: -CENTER
                                //Spacer()
                                
                                VStack(spacing:10){
                                    Text(onboardingScreens[it].title)
                                        .font(.title)
                                        .fontWeight(.heavy)
                                        .foregroundColor(.black)
                                    
                                    Text(onboardingScreens[it].description)
                                        .font(.body)
                                        .fontWeight(.regular)
                                        .foregroundColor(Color("Secondary"))
                                        .lineLimit(nil)
                                        .multilineTextAlignment(.center)
                                        .padding(.horizontal)
                                }
                                //: CENTER
                                
                                
                                
                                // MARK: -FOOTER
                                
                                HStack{
                                    if onboardingScreens[it].showsButton {
                                        Button(action: {shouldShowOnboarding.toggle()
                                            SoundManager.instance.playSound()
                                        }, label: {
                                            
                                            Text("Next")
                                                .foregroundColor(Color("Accent"))
                                                .padding(.horizontal,24)
                                                .padding(.vertical,8)
                                                .background(.thinMaterial)
                                                .cornerRadius(20)
                                        })
                                    }
                                }.padding(.all, 60)
                                
                            }
                        }
                        .tag(it)
                    }
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .overlay(
                HStack{
                    ForEach(0..<onboardingScreens.count){ it in
                        if it == indexPage {
                            Circle()
                                .frame(width: 10, height: 10)
                                .foregroundColor(Color("Accent"))
                        }
                        else {
                            Circle().stroke(Color("Accent"), lineWidth: 2)
                                .frame(width: 10, height: 10)
                                .foregroundColor(.white)
                            //.border(Color.blue)
                            
                        }
                    }
                }.padding(.bottom,UIApplication.shared.windows.first?.safeAreaInsets.bottom)
                ,alignment: .bottom
            )
            .toolbar {
                Button(action: {
                    shouldShowOnboarding.toggle()
                    
                }, label: {
                    Text("Skip")
                        .foregroundColor(Color.orange)
                })
            }
        }
    }
    
}

