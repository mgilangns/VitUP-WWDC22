//
//  MainView.swift
//  WWDC22
//
//  Created by Muhammad Gilang Nursyahroni on 17/04/22.
//

import SwiftUI
import AVFoundation



struct MainView: View {
    
    @AppStorage("shouldShowOnboarding") var shouldShowOnboarding: Bool = true
    @StateObject var pomodoroManager = PomodoroManager()
    @StateObject var soundManager = SoundManager()
    
    let timer = Timer
        .publish(every: 1, on: .main, in: .common)
        .autoconnect()
    
    var title: String{
        switch pomodoroManager.pomodoroState {
            
        case .notStarted:
            return "LET'S GET STARTED"
        case .work:
            return "LET'S GET FOCUSED"
        case .rest:
            return "LET'S GET EXERCISE"
        }
    }
    
    var description: String{
        switch pomodoroManager.pomodoroState {
            
        case .notStarted:
            return "Distraction from your phones is the biggest factor in breaking your concentration. Put your iPhone on do not disturb mode before you start. Press the play button to get started."
        case .work:
            return "Focus. If you want to reach that goal so bad you will have to make a sacrifice. Stay focused, stay passionate."
        case .rest:
            return "Start exercise with simple movements like stretching, pushup, and situp. Start small and stay consistent."
        }
    }
    
    
    var body: some View {
        ZStack{
            //MARK: Background
            Color("BgColor1")
                .ignoresSafeArea(.all, edges: .all)
            Image("BgAssettColor")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            content
            
                .fullScreenCover(isPresented: $shouldShowOnboarding, content: { OnboardingView(shouldShowOnboarding: $shouldShowOnboarding)
                })
        }
    }
    
    var content: some View {
        VStack{
            VStack(spacing: 40){
                //MARK: Title
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(Color("Accent"))
                
                    .padding(.top, 24)
                
                //MARK: Pomodoro Plan
                
            }
            .padding()
            
            VStack(spacing: 15){
                Text(description)
                    .italic()
                    .multilineTextAlignment(.center)
                    .font(.body)
                
                Button {
                action: do {shouldShowOnboarding.toggle()
                    SoundManager.instance.playSound()
                }
                    
                } label: {
                    Image(systemName: "info.circle")
                        .font(.headline)
                        .foregroundColor(Color("Accent"))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(.thinMaterial)
                        .cornerRadius(15)
                }
                //MARK: Progress Ring
                
                ProgressRing()
                    .environmentObject(pomodoroManager)
                Button {
                    pomodoroManager.togglePomodoroState()
                    SoundManager.instance.playSound()
                } label: {
                    Text(pomodoroManager.pomodoroState == .work ? "Skip to exercise" : "Skip to work")
                        .font(.body)
                        .fontWeight(.light)
                        .foregroundColor(Color("Accent"))
                }.padding(.horizontal,24)
                    .padding(.vertical,8)
                    .background(.thinMaterial).opacity(0.7)
                    .cornerRadius(20)
                    .disabled(pomodoroManager.pomodoroState == .notStarted ? true : false)
                    .opacity(pomodoroManager.pomodoroState == .notStarted ? 0 : 1)
                HStack(spacing: 30){
                    //MARK: Start Time
                    
                    VStack(spacing: 5){
                        
                        Text("Start")
                            .opacity(0.7)
                        
                        Text(pomodoroManager.pomodoroState == .notStarted ? "0:00" : "\(pomodoroManager.startTime, style: .timer)")
                            .fontWeight(.bold)
                    }.padding(.horizontal,24)
                        .padding(.vertical,8)
                        .background(.thinMaterial)
                        .cornerRadius(20)
                    
                    
                    //MARK: Button
                    
                    Button {
                        
                        pomodoroManager.toggleStart()
                        SoundManager.instance.playSound()
                    } label: {
                        
                        Text(pomodoroManager.pomodoroState == .notStarted ? Image(systemName: "play.fill") : Image(systemName: "stop.fill") )
                            .font(.system(size: 24))
                            .fontWeight(.bold)
                            .foregroundColor(Color("Accent"))
                            .padding(.horizontal,24)
                            .padding(.vertical,16)
                            .background(.thinMaterial)
                            .cornerRadius(20)
                        
                    }
                    
                    //MARK: End Time
                    
                    VStack(spacing: 5){
                        
                        Text("End")
                            .opacity(0.7)
                        
                        Text(pomodoroManager.pomodoroState == .notStarted ? "0:00" : "\(pomodoroManager.endTime, style: .timer)")
                            .fontWeight(.bold)
                    }
                    .padding(.horizontal,24)
                    .padding(.vertical,8)
                    .background(.thinMaterial)
                    .cornerRadius(20)
                }
            }
            .padding()
        }
        .foregroundColor(.black)
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}

