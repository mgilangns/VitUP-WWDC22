//
//  OnboardingModel.swift
//  WWDC22
//
//  Created by Muhammad Gilang Nursyahroni on 17/04/22.
//

import SwiftUI

struct OnboardingModel: Identifiable{
    var id = UUID()
    var bgImage: String
    var title: String
    var description: String
    var showsButton: Bool
}


var onboardingScreens: [OnboardingModel] = [
    OnboardingModel(id: UUID(),bgImage: "Hi", title: "Hi, welcome to VitUP!", description: """
                    The pandemic era Covid-19 accelerated existing trends in remote work and online learning. It’s presented a unique set of challenge for us, especially remote work fatigue.
                    """,showsButton: false),
    OnboardingModel(id: UUID(), bgImage: "Work", title: "Focused session", description: "VitUP focused session empowers you to manage distraction and control your own time, focused session helps maintain your motivation by chunking your time, and decreasing mental fatigue",showsButton: false),
    OnboardingModel(id: UUID(), bgImage: "Exercise", title: "Exercise session", description: "VitUP exercise session empowers you to make simple exercise movements like stretching, pushup, and situp. Exercise helps improve health, mental health, and sharpness",showsButton: true)
]

